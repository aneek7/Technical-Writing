var searchData=
[
  ['add_0',['add',['../classCalculator.html#aa2ff0467fe8a15b7a544109c42743d99',1,'Calculator']]]
];
