var classCalculator =
[
    [ "add", "classCalculator.html#aa2ff0467fe8a15b7a544109c42743d99", null ],
    [ "multiply", "classCalculator.html#aaa7f94830e3d673792638ca17dbd69f5", null ]
];